import json
import re
from datetime import datetime, timedelta
from bson import ObjectId
from flask import Flask, render_template, request, session, redirect
import pymongo
import os

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
APP_ROOT = APP_ROOT + "/static"

myClient = pymongo.MongoClient('mongodb+srv://imsurya19:imsurya19@cluster.fxkk1jm.mongodb.net/test')
mydb = myClient["MovieOrganization"]
location_col = mydb['Location']
movie_col = mydb["Movies"]
Theatre_col = mydb["Theatre"]
Studio_col = mydb["Studio"]
Distributor_col = mydb["Distributor"]
schedule_col = mydb['Schedules']
screen_col = mydb['Screens']
admin_col = mydb['Admin']
app = Flask(__name__)
app.secret_key = "aaaaaa"

if admin_col.count_documents({}) == 0:
    admin_col.insert_one({"username": "admin", "password": "admin", "role": "admin"})

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/alogin")
def alogin():
    return render_template("alogin.html")


@app.route('/alogin1', methods=['post'])
def alogin1():
    Username = request.form.get("Username")
    Password = request.form.get("Password")
    query ={"username":Username,"password":Password}
    admin = admin_col.find_one(query)
    if admin!=None:
        session['role'] = 'admin'
        return render_template("ahome.html")
    else:
        return render_template("msg.html", msg='Invalid Login Details', color='bg-danger')


@app.route("/ahome")
def ahome():
    return render_template("ahome.html")


@app.route("/studiologin")
def studiologin():
    return render_template("studiologin.html")


@app.route("/studiologin1", methods=['post'])
def studiologin1():
    email = request.form.get("email")
    password = request.form.get("password")
    mycol = mydb["Studio"]
    myquery = {"email": email, "password": password}
    total_count = mycol.count_documents(myquery)
    if total_count > 0:
        results = mycol.find(myquery)
        for result in results:
            if result['status'] == 'authorized':
                session['Studio_id'] = str(result['_id'])
                session['role'] = 'Studio'
                return redirect('/shome')
            else:
                return render_template("msg.html", msg=" Your Account is not Verified", color='bg-danger')
    else:
        return render_template("msg.html", msg="Invalid login details", color='bg-danger')


@app.route("/shome")
def shome():
    Studio_id = session['Studio_id']
    query = {"_id": ObjectId(Studio_id)}
    Studio = Studio_col.find_one(query)
    return render_template("shome.html", Studio=Studio)


@app.route("/studioReg")
def studioReg():
    return render_template("studioReg.html")


@app.route("/StudioReg1", methods=['post'])
def StudioReg1():
    name = request.form.get("name")
    email = request.form.get("email")
    phone = request.form.get("phone")
    password = request.form.get("password")
    address = request.form.get("address")
    mycol = mydb["Studio"]
    total_count = mycol.count_documents({'$or': [{"email": email}, {"phone": phone}]})
    if total_count > 0:
        return render_template("msg.html", msg='Details Already exists', color='bg-danger')
    else:
        mydb.Studio.insert_one(
            {"name": name, "email": email, "phone": phone, "password": password,
             "address": address, 'status': 'unauthorized'})
        return render_template('msg.html', msg=' Studio  Registered successfully', color='bg-success')

@app.route("/distributorlogin")
def distributorlogin():
    return render_template("distributorlogin.html")


@app.route("/distributorlogin1", methods=['post'])
def distributorlogin1():
    email = request.form.get("email")
    password = request.form.get("password")
    mycol = mydb["Distributor"]
    myquery = {"email": email, "password": password}
    total_count = mycol.count_documents(myquery)
    if total_count > 0:
        results = mycol.find(myquery)
        for result in results:
            if result['status'] == 'authorized':
                session['Distributor_id'] = str(result['_id'])
                session['role'] = 'Distributor'
                return redirect('/dhome')
            else:
                return render_template("msg.html", msg=" Your Account is not Verified", color='bg-danger')
    else:
        return render_template("msg.html", msg="Invalid login details", color='bg-danger')

@app.route("/dhome")
def dhome():
    Distributor_id = session['Distributor_id']
    query = {"_id": ObjectId(Distributor_id)}
    Distributor = Distributor_col.find_one(query)
    return render_template("dhome.html", Distributor=Distributor)


@app.route("/distributorReg")
def distributorReg():
    return render_template("distributorReg.html")

@app.route("/DistributorReg1", methods=['post'])
def DistributorReg1():
    name = request.form.get("name")
    email = request.form.get("email")
    region = request.form.get("region")
    #no_of_theatres= request.form.get("no_of_theatres")
    # gender = request.form.get("gender")
    password = request.form.get("password")
    mycol = mydb["Distributor"]
    total_count = mycol.count_documents({'$or': [{"region": region}, {"name": name}]})
    if total_count > 0:
        return render_template("msg.html", msg='Details Already exists', color='bg-danger')
    else:
        mydb.Distributor.insert_one(
            {"name": name, "email": email, "region": region, "password": password, 'status': 'unauthorized'})
        return render_template('msg.html', msg=' Distibutor Registered successfully', color='bg-success')

@app.route("/tlogin")
def tlogin():
    return render_template("tlogin.html")


@app.route("/tlogin1", methods=['post'])
def tlogin1():
    email = request.form.get("email")
    password = request.form.get("password")
    mycol = mydb["Theatre"]
    myquery = {"email": email, "password": password}
    total_count = mycol.count_documents(myquery)
    if total_count > 0:
        results = mycol.find(myquery)
        for result in results:
            if result['status'] == 'authorized':
                session['Theatre_id'] = str(result['_id'])
                session['role'] = 'Theatre'
                return redirect('/thome')
            else:
                return render_template("msg.html", msg=" Your Account Is Not Verified", color='bg-danger')
    else:
        return render_template("msg.html", msg="Invalid login details", color='bg-danger')


@app.route("/thome")
def thome():
    Theatre_id = session['Theatre_id']
    query = {"_id": ObjectId(Theatre_id)}
    Theatre = Theatre_col.find_one(query)
    return render_template("thome.html", Theatre=Theatre)


@app.route("/theatreReg")
def theatreReg():
    locations = location_col.find()
    return render_template("theatreReg.html", locations=locations)


@app.route("/theatreReg1", methods=['post'])
def theatreReg1():
    location_id = request.form.get('location_id')
    distributor_id = session['Distributor_id']
    name = request.form.get("name")
    email = request.form.get("email")
    phone = request.form.get("phone")
    password = request.form.get("password")
    address = request.form.get("address")
    total_count = Theatre_col.count_documents({'$or': [{"email": email}, {"phone": phone}]})
    if total_count > 0:
        return render_template("msg.html", msg='Details Already exists', color='bg-danger')
    else:
        query = {"location_id": ObjectId(location_id),"Distributor_id": ObjectId(distributor_id), "name": name, "email": email, "phone": phone, "password": password,"address": address, 'status': 'unauthorized'}
        Theatre_col.insert_one(query)
        return render_template('msg.html', msg=' Theatre  Registered successfully', color='bg-success')


@app.route("/viewstudio")
def viewstudio():
    mycol = mydb["Studio"]
    query = {}
    studios = mycol.find(query)
    return render_template("viewstudio.html", studios=studios)

@app.route("/viewdistributor")
def viewdistributor():
    mycol = mydb["Distributor"]
    if session['role']=='Theatre':
        theatre_col =mydb["Theatre"]
        current_record = session['Theatre_id']
        #print(current_record)
        query = {"_id": theatre_col.find({"_id": ObjectId(current_record)},{"_id":0,"Distributor_id":1})[0]['Distributor_id']}
        #print(query)
    else:
        query = {}
    distributors = mycol.find(query)
    return render_template("viewdistributor.html", distributors=distributors)


@app.route("/studiostatus1")
def studiostatus1():
    Studio_id = ObjectId(request.args.get("Studio_id"))
    mycol = mydb["Studio"]
    query = {'$set': {"status": 'unauthorized'}}
    result = mycol.update_one({'_id': Studio_id}, query)
    return viewstudio()


@app.route("/studiostatus")
def studiostatus():
    Studio_id = ObjectId(request.args.get("Studio_id"))
    mycol = mydb["Studio"]
    query2 = {'$set': {"status": 'authorized'}}
    result = mycol.update_one({'_id': Studio_id}, query2)
    return viewstudio()

@app.route("/distributorstatus1")
def distributorstatus1():
    Distributor_id = ObjectId(request.args.get("Distributor_id"))
    mycol = mydb["Distributor"]
    query = {'$set': {"status": 'unauthorized'}}
    result = mycol.update_one({'_id': Distributor_id}, query)
    return viewdistributor()


@app.route("/distributorstatus")
def distributorstatus():
    Distributor_id = ObjectId(request.args.get("Distributor_id"))
    mycol = mydb["Distributor"]
    query2 = {'$set': {"status": 'authorized'}}
    result = mycol.update_one({'_id': Distributor_id}, query2)
    return viewdistributor()


@app.route("/viewtheatre")
def viewtheatre():
    mycol = mydb["Theatre"]
    current_Distributor_id = session['Distributor_id']
    query = {'Distributor_id' : ObjectId(current_Distributor_id)}
    theatres = mycol.find(query)
    return render_template("viewtheatre.html", theatres=theatres)


@app.route("/tstatus1")
def tstatus1():
    Theatre_id = ObjectId(request.args.get("Theatre_id"))
    mycol = mydb["Theatre"]
    query = {'$set': {"status": 'unauthorized'}}
    result = mycol.update_one({'_id': Theatre_id}, query)
    return viewtheatre()


@app.route("/tstatus")
def tstatus():
    Theatre_id = ObjectId(request.args.get("Theatre_id"))
    mycol = mydb["Theatre"]
    query2 = {'$set': {"status": 'authorized'}}
    result = mycol.update_one({'_id': Theatre_id}, query2)
    return viewtheatre()


@app.route("/addmovie")
def addmovie():
    Studio_id = session['Studio_id']
    return render_template("addmovie.html", Studio_id=Studio_id)


@app.route("/addmovie1", methods=['post'])
def addmovie1():
    Studio_id = request.form.get('Studio_id')
    movie_name = request.form.get("movie_name")
    release_year = request.form.get("release_year")
    certification = request.form.get("certification")
    description = request.form.get("description")

    poster = request.files['poster']
    certificate_pic = request.files['certificate_pic']
    path = APP_ROOT + "/pictures/" + poster.filename
    poster.save(path)

    path = APP_ROOT + "/pictures/" + certificate_pic.filename
    certificate_pic.save(path)

    total_count = movie_col.count_documents({"movie_name": movie_name})
    if total_count > 0:
        return render_template("msg.html", msg='Details Already Exists', color='bg-danger')
    else:
        query = {"Studio_id": ObjectId(Studio_id), "movie_name": movie_name, "release_year": release_year, "certification": certification, "poster": poster.filename, "description": description, "certificate_pic":certificate_pic.filename}
        movie_col.insert_one(query)
        return render_template('msg.html', msg='Movie Added  successfully', color='bg-success')


@app.route("/viewmovie")
def viewmovie():
    Studio_id = None
    if session['role'] == 'Studio':
        Studio_id = session['Studio_id']
        movie_name = request.args.get('movie_name')
        if movie_name == None or movie_name == '':
            query = {"Studio_id": ObjectId(Studio_id)}
        else:
            rgx = re.compile(".*" + movie_name + ".*", re.IGNORECASE)
            query = {"Studio_id": ObjectId(Studio_id), "$or": [{"movie_name": rgx}, {"release_year": rgx}]}
    elif session['role'] == 'Distributor':
        Studio_id = request.args.get('Studio_id')
        movie_name = request.args.get('movie_name')
        if (Studio_id == None and movie_name == None) or (Studio_id == '' and movie_name == ''):
            query = {}
        elif Studio_id == '' and movie_name != '':
            rgx = re.compile(".*" + movie_name + ".*", re.IGNORECASE)
            query = {"$or": [{"movie_name": rgx}, {"release_year": rgx}]}
        elif Studio_id != '' and movie_name == '':
            query = {"Studio_id": ObjectId(Studio_id)}
        elif Studio_id != '' and movie_name != '':
            rgx = re.compile(".*" + movie_name + ".*", re.IGNORECASE)
            query = {"Studio_id": ObjectId(Studio_id), "$or": [{"movie_name": rgx}, {"release_year": rgx}]}

    movies = movie_col.find(query)
    Studios = Studio_col.find()
    return render_template("viewmovie.html", movies=movies, Studios=Studios, Studio_id=Studio_id, movie_name=movie_name)


@app.route("/certification")
def certification():
    mycol = mydb["Movies"]
    query = {}
    movies = mycol.find(query)
    return render_template("certification.html", movies=movies)


@app.route("/certification1", methods=['post'])
def certification1():
    movie_id = request.form.get("movie_id")
    mycol = mydb["Movies"]
    query = {}
    movies = mycol.find(query)
    return render_template("certification.html", movies=movies)


def getschedule(schedule_id):
    schedule_col = mydb["Schedule"]
    schedules = schedule_col.find({"_id": ObjectId(schedule_id)})
    return schedules


@app.route("/addLocation")
def addLocation():
    return render_template("addLocation.html")


@app.route("/addLocation1", methods=['post'])
def addLocation1():
    location_name = request.form.get('location_name')
    query = {"location_name": location_name}
    location_col.insert_one(query)
    return render_template("msg.html", msg="Location Added Successfully", color="bg-success text-white")


@app.route("/viewLocation")
def viewLocation():
    locations = location_col.find()
    return render_template("viewLocation.html", locations=locations)


@app.route("/addScreen")
def addScreen():
    Theatre_id = ObjectId(session['Theatre_id'])
    return render_template("addScreen.html", Theatre_id=Theatre_id)


@app.route("/addScreen1", methods=['post'])
def addScreen1():
    Theatre_id = request.form.get('Theatre_id')
    screen = request.form.get('screen')
    show_one = request.form.get('show_one')
    show_two = request.form.get('show_two')
    show_three = request.form.get('show_three')
    show_four = request.form.get('show_four')
    number_of_seats = request.form.get('number_of_seats')
    timings = [show_one, show_two, show_three, show_four]
    query = {"Theatre_id": ObjectId(Theatre_id), "screen": screen, "timings": timings, "number_of_seats": number_of_seats}
    screen_col.insert_one(query)
    return render_template("msg.html", msg="Screen Details Added Successfully", color="bg-success text-white")


def get_theatre_Id(Theatre_id):
    query = {'_id': Theatre_id}
    Theatre = Theatre_col.find_one(query)
    return Theatre


def get_screen_Id(screen_id):
    query = {'_id': screen_id}
    screen = screen_col.find_one(query)
    return screen

def get_distributor_Id(Distributor_id):
    query = {'_id': Distributor_id}
    distributor = Distributor_col.find_one(query)
    return distributor

def get_movie_Id(movie_id):
    query = {'_id': movie_id}
    movie = movie_col.find_one(query)
    return movie


@app.route("/viewScreens")
def viewScreens():
    Theatre_id = session['Theatre_id']
    query = {"Theatre_id": ObjectId(Theatre_id)}
    screens = screen_col.find(query)
    return render_template("viewScreens.html", screens=screens, get_theatre_Id=get_theatre_Id)


@app.route("/buyLicense")
def buyLicense():
    movie_id = request.args.get('movie_id')
    mycol = mydb["Theatre"]
    current_Distributor_id = session['Distributor_id']
    query = {'Distributor_id' : ObjectId(current_Distributor_id)}
    theatres = mycol.find(query)
    return render_template("buyLicense.html", movie_id=movie_id, theatres=theatres)


@app.route("/buyLicense1", methods=['post'])
def buyLicense1():
    movie_id = request.form.get('movie_id')
    start_date_time = request.form.get('start_date_time')
    end_date_time = request.form.get('end_date_time')
    start_date_time = start_date_time.replace("T"," ")
    end_date_time = end_date_time.replace("T", " ")
    start_date_time2 = datetime.strptime(start_date_time, '%Y-%m-%d %H:%M')
    end_date_time2 = datetime.strptime(end_date_time, '%Y-%m-%d %H:%M')
    if start_date_time2 > end_date_time2:
        return render_template("msg.html", msg="Invalid Timings", color="bg-danger text-white")
    date = datetime.now()
    status = "Movie Schedule Request Sent"
    theatre_ids = request.form.getlist('theatre_ids')
    for theatre_id in theatre_ids:
        query = {"theatre_id": ObjectId(theatre_id), "status": {"$nin": ["Movie Schedule Cancelled"]}}
        Schedules = schedule_col.find(query)
        if Schedules!=None:
            Schedules = list(Schedules)
            if len(Schedules) != 0:
                for Schedule in Schedules:
                    start_time = datetime.strptime(Schedule['start_date_time'], '%Y-%m-%d %H:%M')
                    end_time = datetime.strptime(Schedule['end_date_time'], '%Y-%m-%d %H:%M')
                    if (start_date_time2 < start_time and end_date_time2 < start_time) or (
                            start_date_time2 > end_time and end_date_time2 > end_time):
                        pass
                    else:
                        return render_template("msg.html", msg="The Timings already Assigned for the screen in this dates", color="bg-danger text-white")
        query = {"movie_id": ObjectId(movie_id), "Theatre_id":ObjectId(theatre_id),"Distributor_id":ObjectId(session['Distributor_id']), "start_date_time": start_date_time, "end_date_time": end_date_time, "date": date, "status": status}
        schedule_col.insert_one(query)
    return render_template("msg.html", msg="Schedule Added Successfully", color="bg-success text-white")


@app.route("/viewContractRequest")
def viewContractRequest():
    movie_id = request.form.get('movie_id')
    query = {}
    if session['role'] == 'Theatre':
        query = {"Theatre_id": ObjectId(session['Theatre_id'])}
        screens = screen_col.find(query)
        screen_ids = []
        for screen in screens:
            screen_ids.append({"screen_id": screen['_id']})
        if len(screen_ids) == 0:
            return render_template("msg.html", msg="No Screens Available", color="bg-danger")
        query = {"$or": screen_ids}
        print(query)
    elif session['role'] == 'Studio':
        movie_id = request .args.get('movie_id')
        query = {"movie_id": ObjectId(movie_id)}
    schedules = schedule_col.find(query)
    return render_template("viewContractRequest.html", schedules=schedules, get_theatre_Id=get_theatre_Id,
                           get_distributor_Id=get_distributor_Id, get_movie_Id=get_movie_Id,movie_id=movie_id)


@app.route("/licenseAmount", methods=['post'])
def licenseAmount():
    schedule_id = request.form.get('schedule_id')
    movie_id = request.form.get('movie_id')
    license_amount = request.form.get('license_amount')
    query = {"_id": ObjectId(schedule_id)}
    query2 = {"$set": {"license_amount": license_amount, "status": "Quote Schedule Approved"}}
    schedule_col.update_one(query, query2)
    return redirect("viewContractRequest?movie_id="+str(movie_id))


@app.route("/payAmount")
def payAmount():
    schedule_id = request.args.get('schedule_id')
    schedule = schedule_col.find_one({"_id" : ObjectId(schedule_id)})
    license_amount = schedule['license_amount']
    return render_template("payAmount.html", schedule_id=schedule_id, license_amount=license_amount)


@app.route("/payAmount1", methods=['post'])
def payAmount1():
    schedule_id = request.form.get('schedule_id')
    query = {"_id": ObjectId(schedule_id)}
    query2 = {"$set": {"status": "Movie License Issued"}}
    schedule_col.update_one(query, query2)
    return render_template("msg.html", msg="License Amount Paid Successfully", color="bg-success")


@app.route("/cancelled")
def cancelled():
    schedule_id = request.args.get('schedule_id')
    query = {'_id': ObjectId(schedule_id)}
    query1 = {"$set": {"status": "Movie Schedule Cancelled"}}
    schedule_col.update_one(query, query1)
    return redirect("/viewContractRequest")

@app.route("/logout")
def logout():
    if session['role'] == 'Theatre':
        session['role'] = 'Distributor'
        return redirect('/dhome')
    else:
        session.clear()
        return render_template("index.html")


app.run(debug=True)