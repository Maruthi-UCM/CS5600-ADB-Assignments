import json
import re
import datetime
from datetime import timedelta
from bson import ObjectId
from flask import Flask, render_template, request, session, redirect
import pymongo
import os

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
APP_ROOT = APP_ROOT + "/static"

myClient = pymongo.MongoClient('mongodb+srv://DB1:DB1@cluster0.o4gp7hf.mongodb.net/test')
mydb = myClient["DB1"]
Booking_col = mydb["Booking"]
Courts_col = mydb["Courts"]
Timeslot_col = mydb["Timeslot"]
Member_col = mydb["Member"]
Schedule_col = mydb['Schedule']
Sports_col = mydb['Sports']
admin_col = mydb['Admin']
Payment_col=mydb['Payment']
app = Flask(__name__)
app.secret_key = "aaaaaa"

if admin_col.count_documents({}) == 0:
    admin_col.insert_one({"username": "admin", "password": "admin", "role": "admin"})

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/alogin")
def alogin():
    return render_template("alogin.html")


@app.route('/alogin1', methods=['post'])
def alogin1():
    Username = request.form.get("Username")
    Password = request.form.get("Password")
    query ={"username":Username,"password":Password}
    admin = admin_col.find_one(query)
    if admin!=None:
        session['role'] = 'admin'
        return render_template("ahome.html")
    else:
        return render_template("msg.html", msg='Invalid Login Details', color='bg-danger')


@app.route("/ahome")
def ahome():
    return render_template("ahome.html")


@app.route("/customerlogin1", methods=['post'])
def customerlogin1():
    username = request.form.get("username")
    password = request.form.get("password")
    mycol = mydb["Member"]
    myquery = {"username": username, "password": password}
    total_count = mycol.count_documents(myquery)
    if total_count > 0:
        results = mycol.find(myquery)
        for result in results:
            current_date = datetime.date.today().isoformat()
            if result['expiry_date']<=current_date:
                query={'$set':{'membership_status':'Inactive'}}
                mycol.update_one(myquery,query)
                return render_template("payMembership.html",member_id=result)
            if result['membership_status'] == 'Active':
                session['Member_id'] = str(result['_id'])
                session['role'] = 'Member'
                return redirect('/chome')
            else:
                return render_template("payMembership.html",member_id=result)
    else:
        return render_template("msg.html", msg="Invalid login details", color='bg-danger')

@app.route("/chome")
def chome():
    Member_id = session['Member_id']
    query = {"_id": ObjectId(Member_id)}
    Member = Member_col.find_one(query)
    return render_template("chome.html", Member=Member)


@app.route("/customerReg")
def customerReg():
    return render_template("customerReg.html")

@app.route("/customerReg1", methods=['post'])
def customerReg1():
    name = request.form.get("name")
    username = request.form.get("username")
    gender = request.form.get("gender")
    password = request.form.get("password")
    mobile_no=request.form.get("mobile_no")
    current_date = datetime.date.today()
    one_year_from_now = current_date + datetime.timedelta(days=365)
    mycol = mydb["Member"]
    total_count = mycol.count_documents({'$or': [{"name": name}]})
    if total_count > 0:
        return render_template("msg.html", msg='Details Already exists', color='bg-danger')
    else:
        query={"name": name, "username": username, "password": password, 'gender':gender, 'mobile_no':mobile_no, 'start_date':current_date.isoformat(),'expiry_date':one_year_from_now.isoformat(),'membership_status': 'Inactive', 'role':'Member'}
        Member_col.insert_one(query)
        member_id = Member_col.find_one({"username":username},{"_id":1})
        return render_template('paymembership.html',member_id=member_id)

@app.route("/courtReg")
def courtReg():
    Courts = Courts_col.find()
    sports=Sports_col.find()
    return render_template("courtReg.html", Courts=Courts,sports=sports)


@app.route("/courtReg1", methods=['post'])
def courtReg1():
    name = request.form.get("name")
    sport_id = request.form.get("sport_id")
    price = request.form.get("price")
    total_count = Courts_col.count_documents({'$or': [{"name": name}]})
    if total_count > 0:
        return render_template("msg.html", msg='Details Already exists', color='bg-danger')
    else:
        query = {"sport_id": ObjectId(sport_id), "name": name, "price": price+" USD", 'status': 'Inactive'}
        Courts_col.insert_one(query)
        return render_template('msg.html', msg=' Court Registered successfully', color='bg-success')

@app.route("/viewcustomer")
def viewcustomer():
    mycol = mydb["Member"]
    query={}
    customers = mycol.find(query)
    return render_template("viewcustomer.html", customers=customers)

@app.route("/viewsport")
def viewsport():
    mycol = mydb["Sports"]
    query = {}
    sports = mycol.find(query)
    sports = Sports_col.find(query)
    courts = Courts_col.find(query)
    return render_template("viewsport.html", sports=sports, courts=courts)


@app.route("/tstatus1")
def tstatus1():
    court_id = ObjectId(request.args.get("Courts_id"))
    mycol = mydb["Courts"]
    query = {'$set': {"status": 'Inactive'}}
    result = mycol.update_one({'_id': court_id}, query)
    return viewcourt()


@app.route("/tstatus")
def tstatus():
    court_id = ObjectId(request.args.get("Courts_id"))
    mycol = mydb["Courts"]
    query2 = {'$set': {"status": 'Active'}}
    result = mycol.update_one({'_id': court_id}, query2)
    return viewcourt()


@app.route("/addsport")
def addsport():
    return render_template("addsport.html")


@app.route("/addsport1", methods=['post'])
def addsport1():
    name = request.form.get("sport_name")
    type = request.form.get("type")
    category = request.form.get("category")
    poster = request.files['poster']
    path = APP_ROOT + "/pictures/" + poster.filename
    poster.save(path)

    total_count = Sports_col.count_documents({"name": name})
    if total_count > 0:
        return render_template("msg.html", msg='Details Already Exists', color='bg-danger')
    else:
        query = {"name": name, "type": type, "category": category, "poster": poster.filename}
        Sports_col.insert_one(query)
        return render_template('msg.html', msg='Sport Added  successfully', color='bg-success')


@app.route("/viewcourt")
def viewcourt():
    sport_name = request.args.get('Sport_id')
    if sport_name == None or sport_name == '':
        query = {}
    else:
        query = {"sport_id": ObjectId(sport_name)}
    courts = Courts_col.find(query)
    sports = Sports_col.find()
    return render_template("viewcourt.html", courts=courts, sports=sports, sport_name=sport_name)


def get_schedule(schedule_id):
    schedule_col = mydb["Schedule"]
    schedules = schedule_col.find({"_id": ObjectId(schedule_id)})
    return schedules

def get_member(member_id):
    Member_col = mydb["Member"]
    members = Member_col.find_one({"_id": ObjectId(member_id)})
    return members

def get_court(court_id):
    Courts_col = mydb["Courts"]
    courts = Courts_col.find_one({"_id": ObjectId(court_id)})
    return courts

def get_sport(sport_id):
    sports_col = mydb["Sports"]
    sports = sports_col.find_one({"_id": ObjectId(sport_id)})
    return sports

def get_payment(schedule_id):
    payments = Payment_col.find_one({"schedule_id": ObjectId(schedule_id)})
    return payments

def can_flag(time_str,diff):
    now = datetime.datetime.now()
    time_difference = time_str-now
    print(now,time_str)
    return time_difference < timedelta(hours=diff)

def pen_flag(time_str,diff):
    now = datetime.datetime.now()
    time_difference = now-time_str
    print(now,time_str)
    return time_difference >= timedelta(hours=diff)

@app.route("/bookcourt")
def bookcourt():
    court_id = request.args.get('court_id')
    today = datetime.datetime.now().date()
    date_range = [(today + timedelta(days=x)).strftime('%Y-%m-%d') for x in range(7)]
    return render_template("bookcourt.html", court_id=court_id,date_range=date_range)


@app.route("/bookcourt1", methods=['post'])
def bookcourt1():
    court_id = request.form.get('court_id')
    date = request.form.get('Date')
    start_time = request.form.get('start_time')
    end_time = request.form.get('end_time')
    start=int(start_time.split(":")[0])
    end=int(end_time.split(":")[0])
    today = datetime.datetime.now()
    if (start >= end) or (start<=today.hour):
        return render_template("msg.html", msg="Invalid Timings", color="bg-danger text-white")
    status = "Payment Pending"
    query = {"court_id": ObjectId(court_id),"date":date, "status": {"$nin": ["Booking Cancelled"]}}
    Schedules = Schedule_col.find(query)
    if Schedules!=None:
        Schedules = list(Schedules)
        print(Schedules)
        if len(Schedules) != 0:
            for Schedule in Schedules:
                schedule_start=int(Schedule['start_time'].split(":")[0])
                schedule_end=int(Schedule['end_time'].split(":")[0])
                if (schedule_start>=start and schedule_start<end) or (schedule_end<=end and schedule_end>start):
                    return render_template("msg.html", msg="Booking Not available for this Schedule", color="bg-danger text-white")
    query = {"member_id": ObjectId(session['Member_id']),"date":date, "status": {"$nin": ["Booking Cancelled"]}}
    Schedules = Schedule_col.find(query)
    if Schedules!=None:
        Schedules = list(Schedules)
        print(Schedules)
        if len(Schedules) != 0:
            for Schedule in Schedules:
                schedule_start=int(Schedule['start_time'].split(":")[0])
                schedule_end=int(Schedule['end_time'].split(":")[0])
                if (schedule_start>=start and schedule_start<end) or (schedule_end<=end and schedule_end>start):
                    return render_template("msg.html", msg="Booking Not available for this Schedule", color="bg-danger text-white")
    query = {"court_id": ObjectId(court_id),"member_id":ObjectId(session['Member_id']), "Amount":Courts_col.find_one({'_id':ObjectId(court_id)},{'price':1})['price'], "start_time": start_time, "end_time": end_time, "date": date,'c_flag':1,'p_flag':1,'Booking_timestamp':today, "status": status}
    Schedule_col.insert_one(query)
    return redirect('payAmount?schedule_id='+str(Schedule_col.find_one({'member_id':ObjectId(session['Member_id']),'court_id':ObjectId(court_id),'date':date},{'_id':1})['_id']))

@app.route("/viewbookings")
def viewbookings():
    court_id = request.form.get('court_id')
    now = datetime.datetime.now()
    if session['role'] == 'Member':
        query = {'member_id':ObjectId(session['Member_id'])}
        schedules = Schedule_col.find(query)
        for schedule in list(schedules):
            if schedule['status']=='Payment Pending' and now.date()>schedule['Booking_timestamp'].date():
                Schedule_col.update_one({'_id':schedule['_id']},{'$set':{"status":"Booking Cancelled","c_flag":0,"p_flag":0}})
                continue
            elif schedule['status']=='Payment Pending' and now.date()==schedule['Booking_timestamp'].date() and pen_flag(schedule['Booking_timestamp'],2):
                Schedule_col.update_one({'_id':schedule['_id']},{'$set':{"status":"Booking Cancelled","c_flag":0,"p_flag":0}})
                continue
            payment=get_payment(schedule['_id'])
            if schedule['status']=='Booking Done' and now.date()>datetime.datetime.strptime(schedule['date'],'%Y-%m-%d').date():
                Schedule_col.update_one({'_id':schedule['_id']},{'$set':{"c_flag":0}})
                continue
            elif schedule['status']=='Booking Done' and now.date()<=datetime.datetime.strptime(schedule['date'],'%Y-%m-%d').date() and can_flag(payment['purchase_timestamp'],12):
                Schedule_col.update_one({'_id':schedule['_id']},{'$set':{"c_flag":0}})
                continue
    elif session['role'] == 'admin':
        court_id = request.args.get('court_id')
        query = {"court_id": ObjectId(court_id)}
    schedules = Schedule_col.find(query)
    schedules=list(schedules)
    if len(schedules)==0:
        return render_template("msg.html", msg="No Bookings Available", color="bg-danger")
    return render_template("viewbookings.html", schedules=schedules, get_member=get_member,
                           get_sport=get_sport, get_court=get_court, get_payment=get_payment,now=now)


@app.route("/payAmount")
def payAmount():
    schedule_id = request.args.get('schedule_id')
    schedule = Schedule_col.find_one({"_id" : ObjectId(schedule_id)})
    license_amount = schedule['Amount']
    return render_template("payAmount.html", schedule_id=schedule_id, member_id=schedule['member_id'], license_amount=license_amount)


@app.route("/payAmount1", methods=['post'])
def payAmount1():
    if session['role']=="Member":
            schedule_id = request.form.get('schedule_id')
            schedule=Schedule_col.find_one({'_id':ObjectId(schedule_id)})
            query = {"_id": ObjectId(schedule_id)}
            query2 = {"$set": {"status": "Booking Done","c_flag":0,"p_flag":0}}
            Schedule_col.update_one(query, query2)
            Payment_col.insert_one({'schedule_id':ObjectId(schedule_id),'member_id':schedule['member_id'],'Amount_paid':schedule['Amount'],'purchase_timestamp':datetime.datetime.now(),'purchase_type':'Court Booking'})
            return render_template("msg.html", msg="Court Booked Successfully", color="bg-success")
    else:
        return render_template("msg.html", msg="Something went wrong", color="bg-danger")

@app.route("/payAmount2", methods=['post'])
def payAmount2():
    try: 
        member_id = request.form.get('member_id')
        current_date = datetime.date.today()
        one_year_from_now = current_date + datetime.timedelta(days=365)
        query1 = {"_id": ObjectId(member_id)}
        query2 = {"$set":{"membership_status":"Active",'start_date':current_date.isoformat(),'expiry_date':one_year_from_now.isoformat()}}
        Member_col.update_one(query1,query2)
        Payment_col.insert_one({'member_id':ObjectId(member_id),'Amount_paid':"5.00 USD",'purchase_timestamp':datetime.datetime.now(),'purchase_type':'Membership Purchase'})
        return render_template("msg.html", msg="Membership Purchase Succesful", color="bg-warning")
    except:
        return render_template("msg.html", msg="Something went wrong", color="bg-danger")

@app.route("/cancelled")
def cancelled():
    schedule_id = request.args.get('schedule_id')
    query = {'_id': ObjectId(schedule_id)}
    schedule=Schedule_col.find_one(query)
    query1 = {"$set": {"status": "Booking Cancelled"}}
    Schedule_col.update_one(query, query1)
    if schedule['status']!="Payment pending":
        now= datetime.datetime.now()
        Payment_col.update_one({'schedule_id':ObjectId(schedule_id)},{'$set':{'cancellation_timestamp':now,'purchase_type':"Court Booking Cancelled"}})
    return redirect("/viewbookings")


@app.route("/logout")
def logout():
    session.clear()
    return render_template("index.html")

app.run(debug=True)